import { Server } from "./"; 
export interface IDataStore{
    timestamp:number;
    data:string;
}
export class Client{
    store:IDataStore = {timestamp:0,data:undefined}
    server:Server;
    constructor(server:Server){
        this.server = server
    }
    synchronize():void{
        let updatedStore = this.server.synchronize(this.store)
        if(updatedStore){
            this.store = updatedStore
        }
    }
    update(data:string):void{
        this.store.data = data;
        this.store.timestamp = Date.now()
    }
}