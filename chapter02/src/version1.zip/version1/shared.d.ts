export interface IDataStoreInfo{
    timestamp:number;
    data:string;
}